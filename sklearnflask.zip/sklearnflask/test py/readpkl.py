import pandas as pd


data_model = pd.read_pickle('model\model_columns.pkl')

print(data_model)

