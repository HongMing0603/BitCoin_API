import joblib

clf = joblib.load("model\model.pkl")
